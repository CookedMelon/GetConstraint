@tf_export("distribute.coordinator.experimental_get_current_worker_index",
           v1=[])

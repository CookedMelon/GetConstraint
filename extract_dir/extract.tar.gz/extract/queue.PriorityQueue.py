@tf_export("queue.PriorityQueue",
           v1=["queue.PriorityQueue", "io.PriorityQueue", "PriorityQueue"])

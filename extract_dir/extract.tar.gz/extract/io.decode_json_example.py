@tf_export("io.decode_json_example",
           v1=["decode_json_example", "io.decode_json_example"])

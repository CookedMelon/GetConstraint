@tf_export("queue.QueueBase",
           v1=["queue.QueueBase", "io.QueueBase", "QueueBase"])

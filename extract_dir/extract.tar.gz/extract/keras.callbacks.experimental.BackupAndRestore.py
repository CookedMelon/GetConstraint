@keras_export("keras.callbacks.experimental.BackupAndRestore", v1=[])
@deprecation.deprecated_endpoints(
    "keras.callbacks.experimental.BackupAndRestore"

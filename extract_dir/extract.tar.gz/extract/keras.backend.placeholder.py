@keras_export("keras.backend.placeholder")
@doc_controls.do_not_generate_docs
def placeholder(
    shape=None, ndim=None, dtype=None, sparse=False, name=None, ragged=False
